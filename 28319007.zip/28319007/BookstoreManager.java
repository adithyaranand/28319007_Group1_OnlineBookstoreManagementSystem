import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Date;

public class BookstoreManager {
    private HashMap<Integer, Book> books = new HashMap<>();
    private ArrayList<Order> orders = new ArrayList<>();
    private int nextOrderId = 1;

    // Add a new book to the inventory
    public void addBook(Book b) {
        books.put(b.getId(), b);
        System.out.println("Book added: " + b);
    }

    // Remove a book from the inventory
    public void removeBook(int bookId) {
        Book removedBook = books.remove(bookId);
        if (removedBook != null) {
            System.out.println("\nBook removed: " + removedBook);
        } else {
            System.out.println("\nBook not found.");
        }
    }

    // Update details of an existing book
    public void updateBook(int bookId, Book updatedBook) {
        if (books.containsKey(bookId)) {
            books.put(bookId, updatedBook);
            System.out.println("Book updated: " + updatedBook);
        } else {
            System.out.println("Book not found.");
        }
    }

    // Search for books based on the keyword (title, author, or category)
    public void searchBooks(String keyword) {
        boolean found = false;
        for (Book book : books.values()) {
            if (book.getTitle().toLowerCase().contains(keyword.toLowerCase()) ||
                    book.getAuthor().toLowerCase().contains(keyword.toLowerCase()) ||
                    book.getCategory().toLowerCase().contains(keyword.toLowerCase())) {
                System.out.println(book);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No books found with the keyword: " + keyword);
        }
    }

    // Place an order for books
    public void placeOrder(int bookId, int quantity) {
        Book book = books.get(bookId);
        if (book != null && book.getQuantity() >= quantity) {
            book.setQuantity(book.getQuantity() - quantity);
            Order order = new Order(nextOrderId++, bookId, quantity, new Date(), "Pending");
            orders.add(order);
            System.out.println("Order placed: " + order);
        } else {
            System.out.println("\nBook not available or insufficient quantity.");
        }
    }

    // Process an order (update status)
    public void processOrder(int orderId) {
        for (Order order : orders) {
            if (order.getId() == orderId) {
                order.setStatus("Shipped");
                System.out.println("Order processed: " + order);
                return;
            }
        }
        System.out.println("Order not found.");
    }

    // Main method for running the console-based application
    public static void main(String[] args) {
        BookstoreManager manager = new BookstoreManager();
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("\nOnline Bookstore Management System");
            System.out.println("1. Add a Book");
            System.out.println("2. Remove a Book");
            System.out.println("3. Update Book Details");
            System.out.println("4. Search for Books");
            System.out.println("5. Place an Order");
            System.out.println("6. Process an Order");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline left-over

            switch (choice) {
                case 1:
                    System.out.println("Enter book details: ");
                    System.out.print("ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Title: ");
                    String title = scanner.nextLine();
                    System.out.print("Author: ");
                    String author = scanner.nextLine();
                    System.out.print("Category: ");
                    String category = scanner.nextLine();
                    System.out.print("Price: ");
                    double price = scanner.nextDouble();
                    System.out.print("Quantity: ");
                    int quantity = scanner.nextInt();
                    manager.addBook(new Book(id, title, author, category, price, quantity));
                    break;

                case 2:
                    System.out.print("Enter the ID of the book to remove: ");
                    int removeId = scanner.nextInt();
                    manager.removeBook(removeId);
                    break;

                case 3:
                    System.out.print("Enter the ID of the book to update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.println("Enter new details for the book: ");
                    System.out.print("Title: ");
                    String newTitle = scanner.nextLine();
                    System.out.print("Author: ");
                    String newAuthor = scanner.nextLine();
                    System.out.print("Category: ");
                    String newCategory = scanner.nextLine();
                    System.out.print("Price: ");
                    double newPrice = scanner.nextDouble();
                    System.out.print("Quantity: ");
                    int newQuantity = scanner.nextInt();
                    manager.updateBook(updateId,
                            new Book(updateId, newTitle, newAuthor, newCategory, newPrice, newQuantity));
                    break;

                case 4:
                    System.out.print("Enter a keyword to search (title, author, or category): ");
                    String keyword = scanner.nextLine();
                    manager.searchBooks(keyword);
                    break;

                case 5:
                    System.out.print("Enter the ID of the book to order: ");
                    int orderId = scanner.nextInt();
                    System.out.print("Enter the quantity to order: ");
                    int orderQuantity = scanner.nextInt();
                    manager.placeOrder(orderId, orderQuantity);
                    break;

                case 6:
                    System.out.print("Enter the ID of the order to process: ");
                    int processOrderId = scanner.nextInt();
                    manager.processOrder(processOrderId);
                    break;

                case 7:
                    exit = true;
                    System.out.println("Exiting the system. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }
}
